package IDBIConfiguration.v1.impl;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.app.b2b.server.ServerAPI;
import com.wm.util.List;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;
// --- <<IS-END-IMPORTS>> ---

public final class util

{
	// ---( internal utility methods )---

	final static util _instance = new util();

	static util _newInstance() { return new util(); }

	static util _cast(Object o) { return (util)o; }

	// ---( server methods )---




	public static final void getPropertyFrmMemory (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getPropertyFrmMemory)>> ---
		// @sigtype java 3.5
		// [i] field:0:required key
		// [i] field:0:required packageName
		// [o] field:0:required value
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor(); 
		
		try{
		
		String	key = IDataUtil.getString( pipelineCursor, "key" );
		String	packageName = IDataUtil.getString( pipelineCursor, "packageName" );
		
		String value="";
		value=packageMap.get(packageName).get(key);
		// pipeline
		
		IDataUtil.put( pipelineCursor, "value", value );
		pipelineCursor.destroy();
		} catch (Exception e) {	
			IDataUtil.put( pipelineCursor, "value", null );
		}
			
		// --- <<IS-END>> ---

                
	}



	public static final void getPropertyValueListFrmMemory (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getPropertyValueListFrmMemory)>> ---
		// @sigtype java 3.5
		// [i] field:1:required keyList
		// [i] field:0:required packageName
		// [o] record:1:required keyValueList
		// [o] - field:0:required key
		// [o] - field:0:required value
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String[]	keyList = IDataUtil.getStringArray( pipelineCursor, "keyList" );
			String	packageName = IDataUtil.getString( pipelineCursor, "packageName" );
			pipelineCursor.destroy();
			// pipeline
			IDataCursor pipelineCursor_1 = pipeline.getCursor();
			// keyValueList
			IData[]	keyValueList = new IData[keyList.length];
			int index = 0;
			
		for(String key :keyList) {
			String value="";
			try{	
		             value=packageMap.get(packageName).get(key);
			}
			catch (Exception e) {	
				value= "Key Not Found!!";
			}
		keyValueList[index] = IDataFactory.create();
		IDataCursor keyValueListCursor = keyValueList[index].getCursor();
		IDataUtil.put( keyValueListCursor, "key", key );
		IDataUtil.put( keyValueListCursor, "value", value);
		keyValueListCursor.destroy();
		IDataUtil.put( pipelineCursor_1, "keyValueList", keyValueList );
		index++;
		
		}
		
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void loadPropertiesFromCfgFiles (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(loadPropertiesFromCfgFiles)>> ---
		// @sigtype java 3.5
		// [i] field:0:required packageName
		// pipeline
		Map<String, String> keyValueMap = new HashMap<String, String>();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	packageName = IDataUtil.getString( pipelineCursor, "packageName" );
			try{ 
			File configDir = ServerAPI.getPackageConfigDir(packageName);
			File fileDirectory = new File(configDir.toString());
			File[] fileList = null;
			fileList = fileDirectory.listFiles();
			String env=System.getProperty("watt.server.environment");
			keyValueMap.clear();
				for(File file :fileList) {
			
				if (file.getName().toUpperCase().endsWith(("_"+env.toUpperCase()+".CNF")) ){
				Properties prop= new Properties();
				FileInputStream ip = new FileInputStream(file.getAbsolutePath());
				prop.load(ip);
				for (final Entry<Object, Object> entry : prop.entrySet()) {
					keyValueMap.put((String) entry.getKey(), (String) entry.getValue());
			    }}}
			
				packageMap.put(packageName,keyValueMap);
		
		} catch (Exception e) {
			throw new ServiceException(e);
		}
			
		// --- <<IS-END>> ---

                
	}



	public static final void modifyValueInFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(modifyValueInFile)>> ---
		// @sigtype java 3.5
		// [i] field:0:required filePath
		// [i] field:0:required errorMsgKey
		// [i] field:0:required notifyKey
		// [i] field:0:required emailAddrKey
		// [i] field:0:required errorMsgValue
		// [i] field:0:required notifyValue
		// [i] field:0:required emailAddrValue
		// [i] field:0:required propertyKey
		// [i] field:0:required propertyValue
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	filePath = IDataUtil.getString( pipelineCursor, "filePath" );
		String	errorMsgKey = IDataUtil.getString( pipelineCursor, "errorMsgKey" );
		String	notifyKey = IDataUtil.getString( pipelineCursor, "notifyKey" );
		String	emailAddrKey = IDataUtil.getString( pipelineCursor, "emailAddrKey" );
		String	errorMsgValue = IDataUtil.getString( pipelineCursor, "errorMsgValue" );
		String	notifyValue = IDataUtil.getString( pipelineCursor, "notifyValue" );
		String	emailAddrValue = IDataUtil.getString( pipelineCursor, "emailAddrValue" );
		String	propertyKey = IDataUtil.getString( pipelineCursor, "propertyKey" );
		String	propertyValue = IDataUtil.getString( pipelineCursor, "propertyValue" );
		try {
		Properties prop= new Properties();
		FileInputStream ip=new FileInputStream(filePath);
		prop.load(ip);
		/*if(errorMsgKey!=null & prop.containsKey(errorMsgKey)){
			prop.put(errorMsgKey, errorMsgValue);
		}
		if(notifyKey!=null & prop.containsKey(notifyKey)){
			prop.put(notifyKey, notifyValue);
		}
		if(emailAddrKey!=null & prop.containsKey(emailAddrKey)){
			prop.put(emailAddrKey, emailAddrValue);
		}*/
		if(errorMsgKey!=null){
			prop.put(errorMsgKey, errorMsgValue);
		}
		if(notifyKey!=null){
			prop.put(notifyKey, notifyValue);
		}
		if(emailAddrKey!=null){
			prop.put(emailAddrKey, emailAddrValue);
		}
		if(propertyKey!=null){
			prop.put(propertyKey, propertyValue);
		}
		 Map<String, String> sortedMap = new TreeMap(prop);
		 Properties propFinal = new Properties();
		 propFinal.putAll(sortedMap);
		
		 propFinal.store(new FileWriter(filePath), "Modified/Added the key's/value's");
		/*FileOutputStream ip2=new FileOutputStream(filePath);
		ip2.*/
		 pipelineCursor.destroy();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ServiceException(e);
		}
			
		// --- <<IS-END>> ---

                
	}



	public static final void removeProperties (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(removeProperties)>> ---
		// @sigtype java 3.5
		// [i] field:0:required packageName
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	packageName = IDataUtil.getString( pipelineCursor, "packageName" );
		packageMap.remove(packageName);
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	
	
	public static Map<String, Map<String, String>> packageMap = new HashMap<String, Map<String, String>>();
	  
		
	// --- <<IS-END-SHARED>> ---
}

