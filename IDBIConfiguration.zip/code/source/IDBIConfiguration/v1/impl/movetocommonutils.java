package IDBIConfiguration.v1.impl;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.app.b2b.server.ServerAPI;
import com.wm.util.List;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;
// --- <<IS-END-IMPORTS>> ---

public final class movetocommonutils

{
	// ---( internal utility methods )---

	final static movetocommonutils _instance = new movetocommonutils();

	static movetocommonutils _newInstance() { return new movetocommonutils(); }

	static movetocommonutils _cast(Object o) { return (movetocommonutils)o; }

	// ---( server methods )---




	public static final void findItemsInList (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(findItemsInList)>> ---
		// @sigtype java 3.5
		// [i] record:1:required input
		// [i] field:1:required fieldNames
		// [i] field:1:required values
		// [i] field:0:optional condition {"AND","OR"}
		// [o] field:0:required contains
		// [o] field:0:required errorMessage
		// [o] record:1:required output
		IDataCursor pipelineCursor = pipeline.getCursor();
		String contains = "false";
		String errorMessage = null;
		String condition = null;
		ArrayList<IData> output = null;
		try {
		
		
			IData[] input = IDataUtil.getIDataArray(pipelineCursor, "input");
			String[] fieldNames = IDataUtil.getStringArray(pipelineCursor,
					"fieldNames");
			String[] values = IDataUtil
					.getStringArray(pipelineCursor, "values");
			condition = IDataUtil.getString(pipelineCursor, "condition");
			pipelineCursor.destroy();
			boolean check = validationCheck(fieldNames, values, condition,
					input);
			if (check) {
				output=searchList(fieldNames, values, condition, input);
		        if(output!=null&&output.size()>0){
		        	
		        	contains="true";
		        	
		        }
		
			}
		
		} catch (Exception e) {
			errorMessage = throwableToString(e);
		}
		
		finally {
			IDataCursor pipelineCursor_1 = pipeline.getCursor();
			IDataUtil.put(pipelineCursor_1, "contains", contains);
			if (errorMessage != null) {
				IDataUtil.put(pipelineCursor_1, "errorMessage", errorMessage);
			}
			if (output != null&&output.size()>0) {
				IDataUtil.put(pipelineCursor_1, "output",
						output.toArray(new IData[output.size()]));
				output = null;
			}
		
			pipelineCursor_1.destroy();
		}
		
		
			
		// --- <<IS-END>> ---

                
	}



	public static final void getCallingService (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getCallingService)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required callStackLevel
		// [o] field:0:required serviceName
		// [o] field:0:required packageName
		IDataCursor pipelineCursor = pipeline.getCursor();
		int callStackLevel = IDataUtil.getInt ( pipelineCursor, "callStackLevel", 0);
		java.util.Stack callStack = com.wm.app.b2b.server.InvokeState.getCurrentState().getCallStack();
		int getIndex = callStack.size()-callStackLevel-1;
		   
		NSService ns=(com.wm.lang.ns.NSService)callStack.elementAt(getIndex);
		
		String serviceName = ns.toString();
		String packageName=ns.getPackage().toString();
		IDataUtil.put(pipelineCursor, "serviceName", serviceName);
		IDataUtil.put(pipelineCursor, "packageName", packageName.split(":")[1]);
		pipelineCursor.destroy(); 
		// --- <<IS-END>> ---

                
	}



	public static final void getServerProperties (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getServerProperties)>> ---
		// @sigtype java 3.5
		// [o] field:0:required env
		// [o] field:0:required homeDir
		IDataCursor cursor = pipeline.getCursor();
		IDataUtil.put(cursor, "env", System.getProperty("watt.server.environment"));
		IDataUtil.put(cursor, "homeDir", System.getProperty("watt.server.homeDir"));
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	
	
	public static Map<String, Map<String, String>> packageMap = new HashMap<String, Map<String, String>>();
	  
		
	// --- <<IS-END-SHARED>> ---
}

